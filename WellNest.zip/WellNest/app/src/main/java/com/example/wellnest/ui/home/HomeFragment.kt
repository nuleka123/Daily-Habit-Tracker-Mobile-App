package com.example.wellnest.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.wellnest.data.SharedPrefsManager
import com.example.wellnest.databinding.FragmentHomeBinding
import android.util.Log

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: SharedPrefsManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        prefs = SharedPrefsManager(requireContext())
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        updateProgress()
    }

    private fun updateProgress() {
        val habits = prefs.getHabits()
        Log.d("HomeFragment", "Habits count: ${habits.size}")

        if (habits.isEmpty()) {
            binding.progressHabits.progress = 0
            binding.tvGreeting.text = "No habits yet — add some!"
            return
        }

        val done = habits.count { it.completed }
        val percent = (done.toFloat() / habits.size.toFloat() * 100).toInt()

        binding.progressHabits.progress = percent
        binding.tvGreeting.text = "You have completed $done of ${habits.size} habits today."
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
