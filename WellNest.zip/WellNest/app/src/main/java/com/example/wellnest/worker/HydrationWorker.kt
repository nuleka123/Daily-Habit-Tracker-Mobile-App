package com.example.wellnest.worker

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.wellnest.util.NotificationHelper

class HydrationWorker(
    private val ctx: android.content.Context,
    params: WorkerParameters
) : Worker(ctx, params) {

    override fun doWork(): Result {
        // 🔹 Check permission for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                ctx, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

            if (!granted) return Result.success()
        }

        // 🔹 Show notification using helper
        NotificationHelper.showHydrationNotification(
            ctx,
            "Hydration Reminder 💧",
            "Time to drink some water and stay refreshed!"
        )

        return Result.success()
    }
}
