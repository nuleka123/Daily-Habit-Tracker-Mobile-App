package com.example.wellnest.ui.features.mood

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.wellnest.databinding.ItemMoodBinding
import com.example.wellnest.model.MoodEntry
import java.text.SimpleDateFormat
import java.util.*

class MoodAdapter(private val items: List<MoodEntry>) : RecyclerView.Adapter<MoodAdapter.VH>() {

    inner class VH(val binding: ItemMoodBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(m: MoodEntry) {
            val (emoji, label) = when (m.moodValue) {
                1 -> "😭" to "Very Sad"
                2 -> "😔" to "Sad"
                3 -> "😐" to "Neutral"
                4 -> "🙂" to "Good"
                5 -> "😄" to "Happy"
                else -> "😐" to "Neutral"
            }

            binding.tvEmoji.text = emoji
            binding.tvMoodLabel.text = label
            binding.tvTimestamp.text =
                SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(m.timestamp))
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemMoodBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])

    override fun getItemCount(): Int = items.size
}
