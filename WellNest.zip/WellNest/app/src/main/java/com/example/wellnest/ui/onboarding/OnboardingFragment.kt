package com.example.wellnest.ui.onboarding

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.wellnest.databinding.FragmentOnboardingBinding

class OnboardingFragment : Fragment() {
    private var _binding: FragmentOnboardingBinding? = null
    private val binding get() = _binding!!
    private lateinit var data: OnboardingPageData

    companion object {
        private const val ARG_PAGE = "arg_page"
        fun newInstance(data: OnboardingPageData): OnboardingFragment {
            val f = OnboardingFragment()
            val b = Bundle()
            b.putSerializable(ARG_PAGE,data)
            f.arguments = b
            return f
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        data = requireArguments().getSerializable(ARG_PAGE) as OnboardingPageData
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentOnboardingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.tvOnboardTitle.text = data.title
        binding.tvOnboardDesc.text = data.description
        binding.imgOnboard.setImageResource(data.image)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
