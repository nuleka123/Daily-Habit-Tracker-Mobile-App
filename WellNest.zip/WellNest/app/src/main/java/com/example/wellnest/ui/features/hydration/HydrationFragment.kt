package com.example.wellnest.ui.features.hydration

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.wellnest.data.SharedPrefsManager
import com.example.wellnest.databinding.FragmentHydrationBinding
import com.example.wellnest.worker.HydrationWorker
import java.util.concurrent.TimeUnit

class HydrationFragment : Fragment() {
    private var _binding: FragmentHydrationBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: SharedPrefsManager

    private val NOTIF_PERMISSION_CODE = 1001
    private val DEFAULT_INTERVAL_MIN = 60 // default reminder interval

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHydrationBinding.inflate(inflater, container, false)
        prefs = SharedPrefsManager(requireContext())

        // Request notification permission (Android 13+)
        checkAndRequestNotificationPermission()

        // Ensure daily reset
        prefs.ensureHydrationDayReset()

        // Load hydration data
        val goal = prefs.getHydrationGoalMl()
        val today = prefs.getHydrationTodayMl()
        binding.etGoal.setText(goal.toString())
        updateUI(today, goal)

        // Quick add buttons
        binding.btnAddSmall.setOnClickListener { addIntake(100) }
        binding.btnAddMedium.setOnClickListener { addIntake(250) }
        binding.btnAddLarge.setOnClickListener { addIntake(500) }

        // Save goal + schedule reminder
        binding.btnSaveGoal.setOnClickListener {
            val txt = binding.etGoal.text.toString().trim()
            val newGoal = txt.toIntOrNull()
            if (newGoal == null || newGoal <= 0) {
                Toast.makeText(requireContext(), "Enter a valid goal in ml", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            prefs.setHydrationGoalMl(newGoal)

            // Show current reminder status
            var interval = prefs.getHydrationInterval()
            if (interval < 15) {
                interval = DEFAULT_INTERVAL_MIN
                prefs.setHydrationInterval(interval)
                Toast.makeText(requireContext(), "Default interval applied: $DEFAULT_INTERVAL_MIN min", Toast.LENGTH_SHORT).show()
            }

            scheduleWorker(interval)
            binding.tvReminderStatus.text = "Reminder set every $interval min"
            updateUI(prefs.getHydrationTodayMl(), newGoal)
            Toast.makeText(requireContext(), "Goal saved", Toast.LENGTH_SHORT).show()
        }


        return binding.root
    }

    // Request POST_NOTIFICATIONS permission (Android 13+)
    private fun checkAndRequestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    requireContext(),
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    requireActivity(),
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    NOTIF_PERMISSION_CODE
                )
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == NOTIF_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(requireContext(), "Notifications enabled 🎉", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "Permission denied. Notifications won't show.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun addIntake(ml: Int) {
        prefs.ensureHydrationDayReset()
        val today = prefs.getHydrationTodayMl() + ml
        prefs.setHydrationTodayMl(today)
        updateUI(today, prefs.getHydrationGoalMl())
    }

    private fun updateUI(todayMl: Int, goalMl: Int) {
        binding.tvProgress.text = "$todayMl / $goalMl ml"
        val percent = if (goalMl <= 0) 0 else ((todayMl * 100.0f) / goalMl).toInt().coerceIn(0, 100)
        binding.progressHydration.progress = percent
        if (todayMl >= goalMl && goalMl > 0) {
            Toast.makeText(requireContext(), "Goal achieved! 🎉", Toast.LENGTH_SHORT).show()
        }
    }

    private fun scheduleWorker(minutes: Int) {
        val work = PeriodicWorkRequestBuilder<HydrationWorker>(minutes.toLong(), TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(requireContext()).enqueueUniquePeriodicWork(
            "hydration_work",
            ExistingPeriodicWorkPolicy.REPLACE,
            work
        )
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
