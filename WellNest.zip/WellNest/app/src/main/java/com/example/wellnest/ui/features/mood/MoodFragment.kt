package com.example.wellnest.ui.features.mood

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.wellnest.data.SharedPrefsManager
import com.example.wellnest.databinding.FragmentMoodBinding
import com.example.wellnest.model.MoodEntry
import com.example.wellnest.ui.features.mood.chart.MoodChartActivity

class MoodFragment : Fragment() {
    private var _binding: FragmentMoodBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: SharedPrefsManager
    private val moods = mutableListOf<MoodEntry>()
    private lateinit var adapter: MoodAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMoodBinding.inflate(inflater, container, false)
        prefs = SharedPrefsManager(requireContext())
        adapter = MoodAdapter(moods)
        binding.rvMoodHistory.layoutManager = LinearLayoutManager(requireContext())
        binding.rvMoodHistory.adapter = adapter

        setupEmojiGrid()

        binding.btnViewTrend.setOnClickListener {
            startActivity(Intent(requireContext(), MoodChartActivity::class.java))
        }

        loadMoods()
        return binding.root
    }

    private fun setupEmojiGrid() {
        val grid: GridLayout = binding.gridEmojis
        grid.removeAllViews()

        val emojis = listOf("😭", "😔", "😐", "🙂", "😄")
        emojis.forEachIndexed { idx, emoji ->
            val btn = Button(requireContext())
            btn.text = emoji
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(8, 8, 8, 8)
            }
            btn.layoutParams = lp
            btn.setOnClickListener {
                val entry = MoodEntry(moodValue = idx + 1)
                moods.add(0, entry)
                prefs.saveMoods(moods)
                adapter.notifyDataSetChanged()
            }
            grid.addView(btn)
        }
    }

    private fun loadMoods() {
        moods.clear()
        moods.addAll(prefs.getMoods())
        adapter.notifyDataSetChanged()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
