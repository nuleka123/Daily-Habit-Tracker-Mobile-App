package com.example.wellnest.ui.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.wellnest.data.SharedPrefsManager
import com.example.wellnest.databinding.FragmentSettingsBinding

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: SharedPrefsManager

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        prefs = SharedPrefsManager(requireContext())

        setupClickListeners()

        return binding.root
    }

    private fun setupClickListeners() {
        // === PROFILE SECTION ===
        binding.imgEditProfile.setOnClickListener {
            Toast.makeText(requireContext(), "Edit Profile clicked", Toast.LENGTH_SHORT).show()
        }

        binding.imgProfile.setOnClickListener {
            Toast.makeText(requireContext(), "Profile Image clicked", Toast.LENGTH_SHORT).show()
        }

        // === ACCOUNT SECTION ===
        binding.apply {
            // You can add click listeners for each item if needed
            // Example:
            // tvSecurity.setOnClickListener { ... }
        }

        // === SUPPORT & ABOUT SECTION ===
        binding.apply {
            // Example:
            // tvHelpSupport.setOnClickListener { ... }
        }

        // === CACHE & DATA SECTION ===
        binding.btnClear.setOnClickListener {
            prefs.clearAll() // keeps existing functionality
            Toast.makeText(requireContext(), "All data cleared", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
