package com.example.wellnest.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.wellnest.databinding.ActivityLoginBinding
import com.example.wellnest.data.SharedPrefsManager
import com.example.wellnest.ui.main.MainActivity

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var prefs: SharedPrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = SharedPrefsManager(this)

        binding.btnLogin.setOnClickListener {
            val username = binding.etUsername.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()

            if (username.isEmpty()) {
                binding.etUsername.error = "Required"
                return@setOnClickListener
            }
            if (password.isEmpty()) {
                binding.etPassword.error = "Required"
                return@setOnClickListener
            }

            // Get saved username & password from SharedPreferences
            val savedUsername = prefs.getUsername()
            val savedPassword = prefs.getPassword()

            if (username == savedUsername && password == savedPassword) {
                // Login successful → go to MainActivity
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
            }
        }

        // Navigate to RegisterActivity
        binding.tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }
}
