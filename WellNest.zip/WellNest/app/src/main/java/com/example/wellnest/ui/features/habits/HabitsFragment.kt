package com.example.wellnest.ui.features.habits

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.wellnest.data.SharedPrefsManager
import com.example.wellnest.databinding.FragmentHabitsBinding
import com.example.wellnest.model.Habit

class HabitsFragment : Fragment() {
    private var _binding: FragmentHabitsBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: SharedPrefsManager
    private lateinit var adapter: HabitAdapter
    private val list = mutableListOf<Habit>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHabitsBinding.inflate(inflater, container, false)
        prefs = SharedPrefsManager(requireContext())
        adapter = HabitAdapter(list,
            onToggle = { habit, checked ->
                habit.completed = checked
                prefs.saveHabits(list)
            },
            onDelete = { habit ->
                list.remove(habit)
                prefs.saveHabits(list)
                adapter.notifyDataSetChanged()
            })
        binding.rvHabits.layoutManager = LinearLayoutManager(requireContext())
        binding.rvHabits.adapter = adapter

        binding.fabAddHabit.setOnClickListener { showAddDialog() }

        loadHabits()
        return binding.root
    }

    private fun loadHabits() {
        list.clear()
        list.addAll(prefs.getHabits())
        adapter.notifyDataSetChanged()
    }

    private fun showAddDialog() {
        val et = EditText(requireContext())
        et.hint = "Habit title"
        AlertDialog.Builder(requireContext())
            .setTitle("Add habit")
            .setView(et)
            .setPositiveButton("Add") { d, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) {
                    val h = Habit(title = t)
                    list.add(h)
                    prefs.saveHabits(list)
                    adapter.notifyDataSetChanged()
                }
                d.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
