package com.example.wellnest.ui.onboarding

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.wellnest.databinding.ActivityOnboardingBinding
import com.example.wellnest.ui.auth.LoginActivity
import com.google.android.material.tabs.TabLayoutMediator
import com.example.wellnest.R

class OnboardingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOnboardingBinding
    private lateinit var adapter: OnboardingAdapter
    private val pages = listOf(
        OnboardingPageData(
            "Build better habits",
            "Track routines like water, meditation and steps.",
            R.drawable.onboarding1
        ),
        OnboardingPageData(
            "Mood Journal",
            "Quickly log moods with emoji and view trends.",
            R.drawable.onboarding2
        ),
        OnboardingPageData(
            "Stay Hydrated",
            "Set reminders and keep your water intake on track.",
            R.drawable.onboarding3
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = OnboardingAdapter(pages)
        binding.viewPager.adapter = adapter

        TabLayoutMediator(binding.tabLayout, binding.viewPager) { _, _ -> }.attach()

        updateButtons(0)

        // Skip button → go directly to Login
        binding.btnSkip.setOnClickListener {
            goToLogin()
        }

        // Next button → go to next page
        binding.btnNext.setOnClickListener {
            val nextIndex = binding.viewPager.currentItem + 1
            if (nextIndex < pages.size) {
                binding.viewPager.currentItem = nextIndex
            } else {
                goToLogin()
            }
        }

        // Page change listener → show/hide buttons
        binding.viewPager.registerOnPageChangeCallback(object :
            androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                updateButtons(position)
            }
        })
    }

    private fun updateButtons(position: Int) {
        if (position == pages.lastIndex) {
            binding.btnNext.text = "Get Started"
            binding.btnSkip.visibility = android.view.View.GONE
        } else {
            binding.btnNext.text = "Next"
            binding.btnSkip.visibility = android.view.View.VISIBLE
        }
    }

    private fun goToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
