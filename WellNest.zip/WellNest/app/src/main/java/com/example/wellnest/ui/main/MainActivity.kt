package com.example.wellnest.ui.main

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.wellnest.R
import com.example.wellnest.data.SharedPrefsManager
import com.example.wellnest.databinding.ActivityMainBinding
import com.example.wellnest.ui.features.habits.HabitsFragment
import com.example.wellnest.ui.features.hydration.HydrationFragment
import com.example.wellnest.ui.features.mood.MoodFragment
import com.example.wellnest.ui.settings.SettingsFragment
import com.example.wellnest.ui.home.HomeFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: SharedPrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = SharedPrefsManager(this)
        resetHabitsIfNewDay()

        // Set default fragment
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, HomeFragment())
                .commit()
        }

        // Bottom Navigation
        binding.bottomNav.setOnItemSelectedListener { item ->
            val fragment = when(item.itemId) {
                R.id.nav_home -> HomeFragment()
                R.id.nav_habits -> HabitsFragment()
                R.id.nav_mood -> MoodFragment()
                R.id.nav_hydration -> HydrationFragment()
                R.id.nav_settings -> SettingsFragment()
                else -> HomeFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit()
            true
        }
    }

    private fun resetHabitsIfNewDay() {
        val last = prefs.getLastResetDay()
        val today = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis

        if (last < today) {
            val list = prefs.getHabits()
            list.forEach { it.completed = false }
            prefs.saveHabits(list)
            prefs.setLastResetDay(today)
        }
    }
}
