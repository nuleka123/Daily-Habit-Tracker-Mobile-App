package com.example.wellnest.model

import java.util.*

data class MoodEntry(
    val id: String = UUID.randomUUID().toString(),
    val moodValue: Int, // 1..5
    val timestamp: Long = System.currentTimeMillis()
)
