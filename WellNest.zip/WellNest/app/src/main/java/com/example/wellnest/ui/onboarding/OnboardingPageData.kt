package com.example.wellnest.ui.onboarding

import java.io.Serializable

data class OnboardingPageData(
    val title: String,
    val description: String,
    val image: Int
) : Serializable
