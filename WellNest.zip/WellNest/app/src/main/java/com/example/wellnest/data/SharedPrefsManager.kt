package com.example.wellnest.data

import android.content.Context
import com.example.wellnest.model.Habit
import com.example.wellnest.model.MoodEntry
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class SharedPrefsManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("wellnest_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    // --- Keys ---
    private val KEY_USER = "user"
    private val KEY_HABITS = "habits"
    private val KEY_MOODS = "moods"
    private val KEY_HYDRATION_INTERVAL = "hydration_interval"
    private val KEY_LAST_RESET_DAY = "last_reset_day"
    private val KEY_FIRST_LAUNCH = "isFirstLaunch"

    // --- New Keys for Hydration ---
    private val KEY_WATER_INTAKE = "water_intake"
    private val KEY_HYDRATION_GOAL = "hydration_goal"
    private val KEY_REMINDER_STATUS = "hydration_reminder_status"
    private val KEY_LAST_HYDRATION_TIME = "last_hydration_time"

    // --- Key for Login Status ---
    private val KEY_LOGIN_STATUS = "is_logged_in"


    // 👤 USER MANAGEMENT

    fun saveUser(username: String, address: String, email: String, phone: String, password: String) {
        val userMap = mapOf(
            "username" to username,
            "address" to address,
            "email" to email,
            "phone" to phone,
            "password" to password
        )
        prefs.edit().putString(KEY_USER, gson.toJson(userMap)).apply()
    }

    fun saveUser(username: String, password: String) {
        val userMap = mapOf(
            "username" to username,
            "password" to password
        )
        prefs.edit().putString(KEY_USER, gson.toJson(userMap)).apply()
    }

    fun isLoggedIn(): Boolean = prefs.contains(KEY_USER)
    fun clearUser() { prefs.edit().remove(KEY_USER).apply() }

    private fun getUserField(field: String): String? {
        val json = prefs.getString(KEY_USER, null) ?: return null
        val mapType = object : TypeToken<Map<String, String>>() {}.type
        val userMap: Map<String, String> = gson.fromJson(json, mapType)
        return userMap[field]
    }

    fun getUsername(): String? = getUserField("username")
    fun getAddress(): String? = getUserField("address")
    fun getEmail(): String? = getUserField("email")
    fun getPhone(): String? = getUserField("phone")
    fun getPassword(): String? = getUserField("password")


    // 🔑 LOGIN STATUS MANAGEMENT (NEW ADDITIONS)

    fun saveLoginStatus(isLoggedIn: Boolean) {
        prefs.edit().putBoolean(KEY_LOGIN_STATUS, isLoggedIn).apply()
    }

    fun getLoginStatus(): Boolean {
        return prefs.getBoolean(KEY_LOGIN_STATUS, false)
    }

    fun logoutUser() {
        prefs.edit().putBoolean(KEY_LOGIN_STATUS, false).apply()
    }


    // 🧩 HABITS & MOODS

    fun getHabits(): MutableList<Habit> {
        val json = prefs.getString(KEY_HABITS, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<Habit>>() {}.type
        return gson.fromJson(json, type)
    }

    fun saveHabits(list: List<Habit>) {
        prefs.edit().putString(KEY_HABITS, gson.toJson(list)).apply()
    }

    fun getMoods(): MutableList<MoodEntry> {
        val json = prefs.getString(KEY_MOODS, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<MoodEntry>>() {}.type
        return gson.fromJson(json, type)
    }

    fun saveMoods(list: List<MoodEntry>) {
        prefs.edit().putString(KEY_MOODS, gson.toJson(list)).apply()
    }


    // 💧 HYDRATION TRACKER

    fun setHydrationGoalMl(goalMl: Int) {
        prefs.edit().putInt(KEY_HYDRATION_GOAL, goalMl).apply()
    }

    fun getHydrationGoalMl(): Int = prefs.getInt(KEY_HYDRATION_GOAL, 2000) // default 2000ml

    fun setHydrationInterval(minutes: Int) {
        prefs.edit().putInt(KEY_HYDRATION_INTERVAL, minutes).apply()
    }

    fun getHydrationInterval(): Int = prefs.getInt(KEY_HYDRATION_INTERVAL, 0)

    fun setLastResetDay(value: Long) {
        prefs.edit().putLong(KEY_LAST_RESET_DAY, value).apply()
    }

    fun getLastResetDay(): Long = prefs.getLong(KEY_LAST_RESET_DAY, 0L)

    // 🔹 Track how much water drunk today
    fun saveWaterIntake(amountMl: Int) {
        prefs.edit().putInt(KEY_WATER_INTAKE, amountMl).apply()
    }

    fun getWaterIntake(): Int = prefs.getInt(KEY_WATER_INTAKE, 0)

    // 🔹 Helpers for Fragment
    fun getHydrationTodayMl(): Int = getWaterIntake()
    fun setHydrationTodayMl(amountMl: Int) = saveWaterIntake(amountMl)

    // 🔹 Track if reminder ON/OFF
    fun saveReminderStatus(isEnabled: Boolean) {
        prefs.edit().putBoolean(KEY_REMINDER_STATUS, isEnabled).apply()
    }

    fun getReminderStatus(): Boolean = prefs.getBoolean(KEY_REMINDER_STATUS, false)

    // 🔹 Track last hydration reminder time
    fun saveLastHydrationTime(timestamp: Long) {
        prefs.edit().putLong(KEY_LAST_HYDRATION_TIME, timestamp).apply()
    }

    fun getLastHydrationTime(): Long = prefs.getLong(KEY_LAST_HYDRATION_TIME, 0L)

    // 🔹 Reset hydration data daily
    fun resetDailyHydration() {
        prefs.edit()
            .putInt(KEY_WATER_INTAKE, 0)
            .putLong(KEY_LAST_RESET_DAY, System.currentTimeMillis())
            .apply()
    }

    fun ensureHydrationDayReset() {
        val lastReset = getLastResetDay()
        val today = System.currentTimeMillis()
        val oneDayMillis = 24 * 60 * 60 * 1000L
        if (today - lastReset >= oneDayMillis) {
            resetDailyHydration()
        }
    }


    // 🚀 FIRST LAUNCH

    fun isFirstLaunch(): Boolean = prefs.getBoolean(KEY_FIRST_LAUNCH, true)
    fun setFirstLaunchDone() { prefs.edit().putBoolean(KEY_FIRST_LAUNCH, false).apply() }


    // 🧼 CLEAR ALL

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
