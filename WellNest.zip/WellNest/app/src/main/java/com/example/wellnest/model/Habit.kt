package com.example.wellnest.model

import java.util.*

data class Habit(
    val id: String = UUID.randomUUID().toString(),
    var title: String,
    var completed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
