package com.example.wellnest.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.wellnest.databinding.ActivityRegisterBinding
import com.example.wellnest.data.SharedPrefsManager

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private lateinit var prefs: SharedPrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = SharedPrefsManager(this)

        // "Already have an account? Login" click → Go to LoginActivity
        binding.tvGoLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        binding.btnCreateAccount.setOnClickListener {
            val username = binding.etRegUsername.text.toString().trim()
            val address = binding.etRegAddress.text.toString().trim()
            val email = binding.etRegEmail.text.toString().trim()
            val phone = binding.etRegPhone.text.toString().trim()
            val password = binding.etRegPassword.text.toString().trim()

            // Simple validation
            if (username.isEmpty() || address.isEmpty() || email.isEmpty() || phone.isEmpty() || password.isEmpty()) {
                if (username.isEmpty()) binding.etRegUsername.error = "Required"
                if (address.isEmpty()) binding.etRegAddress.error = "Required"
                if (email.isEmpty()) binding.etRegEmail.error = "Required"
                if (phone.isEmpty()) binding.etRegPhone.error = "Required"
                if (password.isEmpty()) binding.etRegPassword.error = "Required"
                return@setOnClickListener
            }

            // Save full user details in SharedPreferences
            prefs.saveUser(username, address, email, phone, password)

            // Navigate to LoginActivity after registration
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
