package com.example.wellnest.ui.features.mood.chart

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class SimpleLineChartView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private val paintLine = Paint().apply {
        color = Color.parseColor("#3F51B5")
        strokeWidth = 6f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }

    private val paintCircle = Paint().apply {
        color = Color.parseColor("#FF9800")
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private var dataPoints: List<Float> = emptyList()

    fun setData(data: List<Float>) {
        dataPoints = data
        invalidate() // Redraw the chart
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (dataPoints.isEmpty()) return

        val widthStep = width.toFloat() / (dataPoints.size - 1).coerceAtLeast(1)
        val maxY = dataPoints.maxOrNull() ?: 1f
        val minY = dataPoints.minOrNull() ?: 0f

        val normalized = dataPoints.map {
            height - ((it - minY) / (maxY - minY + 0.1f)) * height
        }

        for (i in 0 until normalized.size - 1) {
            canvas.drawLine(
                i * widthStep,
                normalized[i],
                (i + 1) * widthStep,
                normalized[i + 1],
                paintLine
            )
        }

        for (i in normalized.indices) {
            canvas.drawCircle(i * widthStep, normalized[i], 10f, paintCircle)
        }
    }
}
