package com.example.wellnest.ui.features.mood.chart

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.wellnest.data.SharedPrefsManager
import com.example.wellnest.databinding.ActivityMoodChartBinding
import java.util.*

class MoodChartActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMoodChartBinding
    private lateinit var prefs: SharedPrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMoodChartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = SharedPrefsManager(this)
        showWeeklyTrend()
    }

    private fun showWeeklyTrend() {
        val moods = prefs.getMoods()
        val cal = Calendar.getInstance()
        val dayValues = mutableListOf<Float>()

        for (i in 6 downTo 0) {
            cal.time = Date()
            cal.add(Calendar.DAY_OF_YEAR, -i)

            val start = cal.timeInMillis
            val end = start + 24 * 60 * 60 * 1000

            val moodForDay = moods.filter { it.timestamp in start..end }
            val avg = if (moodForDay.isEmpty()) 0f else moodForDay.map { it.moodValue }.average().toFloat()
            dayValues.add(avg)
        }

        binding.simpleChart.setData(dayValues)
    }
}
