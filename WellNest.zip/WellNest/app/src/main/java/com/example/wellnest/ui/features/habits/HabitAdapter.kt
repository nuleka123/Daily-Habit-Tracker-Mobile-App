package com.example.wellnest.ui.features.habits

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.wellnest.databinding.ItemHabitBinding
import com.example.wellnest.model.Habit

class HabitAdapter(
    private val items: List<Habit>,
    private val onToggle: (Habit, Boolean) -> Unit,
    private val onDelete: (Habit) -> Unit
) : RecyclerView.Adapter<HabitAdapter.VH>() {

    inner class VH(val binding: ItemHabitBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(habit: Habit, position: Int) {
            // Set habit title
            binding.etHabitName.setText(habit.title)

            // Highlight last item
            if (position == items.size - 1) {
                binding.root.setCardBackgroundColor(Color.parseColor("#D1C4E9")) // light purple
            } else {
                binding.root.setCardBackgroundColor(Color.parseColor("#FFFFFF"))
            }

            // Optional: disable editing if you want static UI
            binding.etHabitName.isEnabled = true

            // Set toggle listener
            binding.cbDone.isChecked = habit.completed
            binding.cbDone.setOnCheckedChangeListener { _, checked ->
                onToggle(habit, checked)
            }

            // Delete button
            binding.btnDelete.setOnClickListener {
                onDelete(habit)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemHabitBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(items[position], position)
    }

    override fun getItemCount(): Int = items.size
}
